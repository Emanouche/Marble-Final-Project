using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;          // Object the camera follows
    public float smoothSpeed = 10f;   // How quickly the camera moves
    private Vector3 offset;           // Initial distance between camera and target

    void Start()
    {
        // Calculate offset based on where the camera starts in the scene
        offset = transform.position - target.position;
    }

    void LateUpdate()
    {
        // Where the camera *should* be this frame
        Vector3 desiredPosition = target.position + offset;

        // Smoothly move camera toward desired position
        transform.position = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);

        // Always look at the target
        transform.LookAt(target.position);
    }
}