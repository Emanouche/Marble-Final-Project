using UnityEngine;

public class RespawnOnFall : MonoBehaviour
{
    private Vector3 startPosition; // Where the ball starts
    private Rigidbody rb;          // Reference to the ball's Rigidbody

    void Start()
    {
        startPosition = transform.position; // Save starting position
        rb = GetComponent<Rigidbody>();     // Get Rigidbody component
    }

    private void OnTriggerEnter(Collider other)
    {
        // Check if we hit the KillZone trigger
        if (other.CompareTag("KillZone"))
        {
            // Stop all movement
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;

            // Teleport ball back to the start
            transform.position = startPosition;
        }
    }
}