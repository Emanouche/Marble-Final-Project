using UnityEngine;

public class QuitOnEscape : MonoBehaviour
{
    private void Awake()
    {
        DontDestroyOnLoad(gameObject); //needed to keep script running to quit game anywhere in the game
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) //quit game when pressing Esc
        {
            Application.Quit();
            Debug.Log("Quit requested");
        }
    }
}
