using UnityEngine;

public class MarbleController : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveForce = 10f;    // Strength of movement force
    public float jumpForce = 5f;     // Strength of jump impulse

    [Header("Ground Check")]
    public float groundCheckDistance = 0.6f; // How far the raycast checks for ground
    public LayerMask groundLayer;            // Which layers count as ground

    private Rigidbody rb; // Rigidbody reference

    void Start()
    {
        rb = GetComponent<Rigidbody>(); // Cache Rigidbody
    }

    void FixedUpdate()
    {
        HandleMovement(); // Movement logic
        HandleJump();     // Jump logic
    }

    void HandleMovement()
    {
        float h = Input.GetAxis("Horizontal"); // Left/Right input
        float v = Input.GetAxis("Vertical");   // Forward/Back input

        // Camera directions
        Vector3 camForward = Camera.main.transform.forward;
        Vector3 camRight = Camera.main.transform.right;

        // Remove vertical tilt
        camForward.y = 0f;
        camRight.y = 0f;

        camForward.Normalize(); // Clean vectors
        camRight.Normalize();

        // Movement relative to camera
        Vector3 moveDir = camForward * v + camRight * h;

        rb.AddForce(moveDir * moveForce); // Apply movement force
    }

    void HandleJump()
    {
        // Jump only when grounded and Space is held
        if (Input.GetKey(KeyCode.Space) && IsGrounded())
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse); // Jump impulse
        }
    }

    bool IsGrounded()
    {
        // Raycast downward to detect ground
        return Physics.Raycast(transform.position, Vector3.down, groundCheckDistance, groundLayer);
    }
}