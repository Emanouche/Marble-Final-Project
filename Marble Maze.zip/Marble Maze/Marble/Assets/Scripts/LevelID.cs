using UnityEngine;

public class LevelID : MonoBehaviour
{
    public int levelNumber; // The level number assigned to this scene

    private void Start()
    {
        PlayerPrefs.SetInt("CurrentLevel", levelNumber); // Save this level as the current one
    }
}