using UnityEngine;
using UnityEngine.SceneManagement;

public class GoalTrigger : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        // Check if the object entering the trigger is the player, marble should be tagged "Player"
        if (other.CompareTag("Player"))
        {
            int currentLevel = PlayerPrefs.GetInt("CurrentLevel", 1); // Read saved level number

            // If we are on Level 5, go to the final screen
            if (currentLevel == 5)
            {
                SceneManager.LoadScene("GameComplete"); // Load final completion scene
            }
            else
            {
                SceneManager.LoadScene("LevelComplete"); // Load the normal level-complete screen
            }
        }
    }
}