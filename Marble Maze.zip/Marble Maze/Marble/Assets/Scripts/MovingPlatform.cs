using UnityEngine;

public class MovingPlatform : MonoBehaviour
{
    public Transform pointA;   // First point the platform moves to
    public Transform pointB;   // Second point the platform moves to
    public float speed = 2f;   // Movement speed

    private Transform currentTarget; // Which point we're moving toward

    void Start()
    {
        currentTarget = pointB; // Start by moving toward B
    }

    void Update()
    {
        // Move toward the current target position
        transform.position = Vector3.MoveTowards(
            transform.position,
            currentTarget.position,
            speed * Time.deltaTime
        );

        // If close enough to the target, switch to the other point
        if (Vector3.Distance(transform.position, currentTarget.position) < 0.05f)
        {
            currentTarget = (currentTarget == pointA) ? pointB : pointA;
        }
    }
}