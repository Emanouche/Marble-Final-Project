using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelCompleteManager : MonoBehaviour
{
    public float delay = 2f; // How long to wait before loading next level

    private void Start()
    {
        int currentIndex = PlayerPrefs.GetInt("CurrentLevel", 1); // Read current level (not used here but stored)
        Invoke("LoadNextLevel", delay); // Call LoadNextLevel after a delay
    }

    void LoadNextLevel()
    {
        int nextLevel = PlayerPrefs.GetInt("CurrentLevel", 1) + 1; // Move to the next level number
        SceneManager.LoadScene("Level_" + nextLevel); // Load the next level scene
    }
}